nugget.addfunction("milkplant_growing_heartbeat", function(th) {
	if (Math.floor(Math.random() * 100000) == 0) {
		th.markfordeletion = null;
		let o = new Thing(OBJECTS.greenmilk, th.x, th.y);
		o.sy = -8;
		obj.push(o);
	}
})